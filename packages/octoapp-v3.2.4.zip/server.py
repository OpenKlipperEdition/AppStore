#!/usr/bin/env python3
"""
OpenKE launcher for OctoApp Companion (moonraker_octoapp).
"""

import sys
import os
import json
import base64

cur_dir = os.path.dirname(os.path.abspath(__file__))
lib_dir = os.path.join(cur_dir, "lib")
if lib_dir not in sys.path:
    sys.path.insert(0, lib_dir)
if cur_dir not in sys.path:
    sys.path.insert(0, cur_dir)

# Ensure child subprocesses inherit PYTHONPATH
existing_pypath = os.environ.get("PYTHONPATH", "")
os.environ["PYTHONPATH"] = f"{lib_dir}:{cur_dir}:{existing_pypath}".strip(":")

# Memory optimizations for embedded devices
os.environ.setdefault("PYTHONOPTIMIZE", "2")
os.environ.setdefault("MALLOC_ARENA_MAX", "1")

# Ensure working directory
os.chdir(cur_dir)

# Storage and logs
storage_path = os.environ.get("OCTOAPP_STORAGE_PATH", "/usr/data/openke/octoapp")
os.makedirs(storage_path, exist_ok=True)

# Locate config paths
cfg_folder = "/opt/printer_data/config"
if not os.path.isdir(cfg_folder) and os.path.isdir("/usr/data/printer_data/config"):
    cfg_folder = "/usr/data/printer_data/config"
elif not os.path.isdir(cfg_folder):
    cfg_folder = storage_path

log_folder = "/opt/printer_data/logs"
if not os.path.isdir(log_folder) and os.path.isdir("/usr/data/printer_data/logs"):
    log_folder = "/usr/data/printer_data/logs"
elif not os.path.isdir(log_folder):
    log_folder = storage_path

moonraker_conf = os.path.join(cfg_folder, "moonraker.conf")
if not os.path.isfile(moonraker_conf):
    moonraker_conf = os.path.join(storage_path, "moonraker.conf")
    if not os.path.isfile(moonraker_conf):
        with open(moonraker_conf, "w", encoding="utf-8") as f:
            f.write("[server]\nhost: 127.0.0.1\nport: 7125\n")

if len(sys.argv) < 2:
    args = {
        'ConfigFolder': cfg_folder,
        'LogFolder': log_folder,
        'LocalFileStoragePath': storage_path,
        'ServiceName': 'octoapp',
        'VirtualEnvPath': '/usr',
        'RepoRootFolder': cur_dir,
        'IsCompanion': False,
        'MoonrakerConfigFile': moonraker_conf
    }
    args_json = json.dumps(args)
    args_b64 = base64.urlsafe_b64encode(args_json.encode("utf-8")).decode("utf-8")
    sys.argv.append(args_b64)

if __name__ == "__main__":
    import runpy
    runpy.run_module("moonraker_octoapp", run_name="__main__")
