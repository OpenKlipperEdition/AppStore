import sys, os

cur_dir = os.path.dirname(os.path.abspath(__file__))
lib_dir = os.path.join(cur_dir, "lib")
if lib_dir not in sys.path:
    sys.path.insert(0, lib_dir)
if cur_dir not in sys.path:
    sys.path.insert(0, cur_dir)

# Set defaults if not set
os.environ.setdefault("SPOOLMAN_PORT", "7912")
os.environ.setdefault("SPOOLMAN_HOST", "0.0.0.0")
os.environ.setdefault("SPOOLMAN_DIR_DATA", "/usr/data/openke/spoolman")
os.environ.setdefault("SPOOLMAN_DIR_LOGS", "/opt/printer_data/logs")

import uvicorn

if __name__ == "__main__":
    port = int(os.environ.get("SPOOLMAN_PORT", 7912))
    host = os.environ.get("SPOOLMAN_HOST", "0.0.0.0")
    uvicorn.run("spoolman.main:app", host=host, port=port, log_level="info")
